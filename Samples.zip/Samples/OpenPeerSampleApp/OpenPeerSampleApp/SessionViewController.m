/*
 
 Copyright (c) 2013, SMB Phone Inc.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:
 
 1. Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
 The views and conclusions contained in the software and documentation are those
 of the authors and should not be interpreted as representing official policies,
 either expressed or implied, of the FreeBSD Project.
 
 */

#import "SessionViewController.h"
#import "ChatViewController.h"

#import "ChatMessageCell.h"
#import "Message.h"


#define DEFAULT_CELL_HEIGHT 35

@interface SessionViewController ()

@end


@implementation SessionViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {

    }
    return self;
}
- (id) initWithSession:(Session*) inSession
{
    self = [self initWithNibName:@"SessionViewController" bundle:nil];
    {
        self.session = inSession;
        self.arrayMessages = inSession.messageArray;
        chatViewController  = [[ChatViewController alloc] initWithSession:self.session];
        [self addChildViewController:chatViewController];
        [chatViewController didMoveToParentViewController:self];
    }
    
    return self;
}
//do not call this from child classes
/*-(id)initWithSession:(Session*)inSession
{
    return nil;
}*/

- (void)dealloc
{
    messageTextbox.delegate = nil;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    //if (!defaultsSet)
    //[self setDefaults];
    
    chatViewController.view.frame = self.view.bounds;
    [self.view addSubview:chatViewController.view];
    
    // Lightning button
    UIButton *menuButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [menuButton setImage:[UIImage imageNamed:@"iPhone_lightning_bolt.png"] forState:UIControlStateNormal];
    [menuButton addTarget:self action:@selector(actionCallMenu) forControlEvents:UIControlEventTouchUpInside];
    [menuButton setFrame:CGRectMake(0.0, 0.0, 40.0, 40.0)];
    UIBarButtonItem *navBarMenuButton = [[UIBarButtonItem alloc] initWithCustomView: menuButton];
    self.navigationItem.rightBarButtonItem = navBarMenuButton;
    
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
//    if (!keyboardIsHidden && (self.session.type == CHAT))
//    {
//        [messageTextbox becomeFirstResponder];
//    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)refreshViewWithData
{
    headerHeight = [self getHeaderHeight:chatHeight];
    
    if (self.arrayMessages && [self.arrayMessages count] > 0)
    {
        [chatTableView reloadData];
        
        [chatTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[self.arrayMessages count] - 1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
}

-(float)getHeaderHeight:(float)tableViewHeight
{
    float res = tableViewHeight;
    
    if (self.arrayMessages && [self.arrayMessages count] > 0)
    {
        // if there is only one empty message, just show history header
//        if ([self.arrayMessages count] == 1 && (((Message *)[self.arrayMessages objectAtIndex:0]).typeOfMessage == HISTORY_LINE))
//        {
//            res -= DEFAULT_CELL_HEIGHT;
//        }
//        else
        {
            for (int i=0; i<[self.arrayMessages count]; i++)
            {
                Message *message = [self.arrayMessages objectAtIndex:i];
                
                //if (m.typeOfMessage == STANDARD_MESSAGE)
                {
                    CGSize cs = [ChatMessageCell calcMessageHeight:message.text forScreenWidth:chatTableView.frame.size.width - 85];
                    res -= (cs.height + 32);
                }
//                else
//                {
//                    res -= DEFAULT_CELL_HEIGHT;
//                }
                
                if (res < 0)
                {
                    res = 1;
                    break;
                }
            } // end of for
        } // end of if
    }
    
    return res;
}

//Implement in child class
- (void)setFramesSizes
{
    
}

- (void) setMessage:(Message *)message;
{
    [self.arrayMessages addObject:message];
}

//Implement in child class
- (void) updateSessionView
{
    
}

-(void)registerForNotifications:(BOOL)registerForNotifications
{
    if (registerForNotifications)
    {
        //   [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resetKeyboard:) name:kResetKeyboardNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
        //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientationChanged) name:kOrientationChanged object:nil];
    }
    else
    {
        //[[NSNotificationCenter defaultCenter] removeObserver:self name:kResetKeyboardNotification object:nil];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
        //[[NSNotificationCenter defaultCenter] removeObserver:self name:kOrientationChanged object:nil];
    }
}

//Implement in child class
- (void) showVideoCall
{
    
}

//Implement in child class
- (void) showAudioCall
{
    
}

- (void) handleCallStateChanged
{
//    if (audioSessionViewController)
//        [audioSessionViewController handleCallStateChanged];
//    
//    if (videoContainerViewController)
//        [videoContainerViewController handleCallStateChanged];
}

/*- (void) handleAudioRouteChanged:(AudioRouteType)route
{
  
}

- (IBAction) closeSession:(id) sender
{
    [self.view endEditing:YES];
    
    BOOL callHangup = self.session.type != CHAT;
    
    //If call is in progress first end call and then in callEnded remove session (put it in inActive state)
    if (callHangup)
    {
        self.shouldCloseSession = YES;
        
        [[ActionManager sharedActionManager] hangupCallForSession:self.session forReason:ICall::CallClosedReason_User];
    }
    else
    {
        [[ActionManager sharedActionManager] changeSessionState:self.session isActive:NO];
    }
}*/
/*
#pragma mark - Table Data Source Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    if(self.arrayMessages)
    {
        return [self.arrayMessages count];
    }
    else
    {
        return 1;
    }
}


- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section 
{
    return headerHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section 
{
    CGRect rect = CGRectMake(0, 0, chatTableView.frame.size.width, chatHeight);
    UIView *v = [[UIView alloc] initWithFrame:rect];
    return [v autorelease];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    NSInteger row = indexPath.row;
    static NSString* MessageCellIdentifier;
    UITableViewCell* msgCell = nil;
    Message* message = nil;
    
    if (self.arrayMessages && [self.arrayMessages count] > 0) 
    {
        message = (Message*)[self.arrayMessages objectAtIndex:row];
    }
    else
    {
        return nil;
    }
    
    if (message.typeOfMessage == SYSTEM_MESSAGE) 
    {
        MessageCellIdentifier = @"systemMessageCellIdentifier";
        
        msgCell = (SystemMessageCell*)[tableView dequeueReusableCellWithIdentifier:MessageCellIdentifier];
        
        if (msgCell == nil) 
        {
            msgCell = [[[SystemMessageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MessageCellIdentifier] autorelease];
        }
        
        [((SystemMessageCell*)msgCell) setMessageText:message.messageText];
        [((SystemMessageCell*)msgCell) setMessageDate:message.messageDate];
        [((SystemMessageCell*)msgCell) setMessageEvent:message.messageEvent];
        [msgCell setNeedsDisplay];
    } 
    else if (message.typeOfMessage == HISTORY_LINE) 
    {
        MessageCellIdentifier = @"historyLineMessageCellIdentifier";
        
        msgCell = (HistoryMessageCell*)[tableView dequeueReusableCellWithIdentifier:MessageCellIdentifier];
        
        if (msgCell == nil) 
        {
            msgCell =[[[HistoryMessageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MessageCellIdentifier] autorelease];        
        }
    } 
    else if (message.typeOfMessage == STANDARD_MESSAGE && message.messageImage != nil) 
    {
        MessageCellIdentifier = @"ImageMessageCellIdentifier";
        
        msgCell = (ImageMessageCell*) [tableView dequeueReusableCellWithIdentifier:MessageCellIdentifier];
        
        if (msgCell == nil) 
        {
            msgCell = [[[ImageMessageCell alloc] initWithFrame:CGRectZero] autorelease];
        }
        
        [((ImageMessageCell*)msgCell) setMessageOwner:message.ownerContact];
        [((ImageMessageCell*)msgCell) setMessageImage:message.messageImage];
        [((ImageMessageCell*)msgCell) setMessageDate:message.messageDate];
    } 
    else 
    {
        MessageCellIdentifier = @"MessageCellIdentifier";
        
        msgCell = (ChatMessageCell*) [tableView dequeueReusableCellWithIdentifier:MessageCellIdentifier];
        
        if (msgCell == nil) 
        {
            msgCell = [[[ChatMessageCell alloc] initWithFrame:CGRectZero] autorelease];
        }
        [((ChatMessageCell*)msgCell) messageLabel].delegate = self;
        [((ChatMessageCell*)msgCell) setMessageOwner:message.ownerContact];
        [((ChatMessageCell*)msgCell) setMessageText:message.messageText];
        [((ChatMessageCell*)msgCell) setMessageImage:message.messageImage];
        [((ChatMessageCell*)msgCell) setMessageDate:message.messageDate];
        ((ChatMessageCell*)msgCell).hasSendingIndicator = NO;
        if(message.deliveryState != hookflash::IConversationThread::MessageDeliveryState_Delivered)
        {
            ((ChatMessageCell*)msgCell).hasSendingIndicator = YES;
        }
    }
    
    return msgCell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    
    float res = 0.0;
    Message *aMsg = [self.arrayMessages objectAtIndex:indexPath.row];
    
    if(aMsg.typeOfMessage != STANDARD_MESSAGE)
    {
        res = DEFAULT_CELL_HEIGHT;
    }
    else
    {
        CGSize textSize = [ChatMessageCell calcMessageHeight:aMsg.messageText forScreenWidth:chatTableView.frame.size.width - 85];
        
        if (aMsg.messageImage)
        {
            textSize = aMsg.messageImage.size;
        }
        
        textSize.height += 32;
        
        res = (textSize.height < 46) ? 46 : textSize.height;
    }
    
    return res;
}

#pragma mark - IM mehods
-(void)sendIMmessage:(NSString *)message toRecipient:(id)recipient forMessageEvent:(MessageEvent)messageEvent andImage:(UIImage*)img
{
    if(message && [[message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] > 0 )
    {
        Message *m = [[Message alloc] init];
        m.messageText = message;
        m.typeOfMessage = messageEvent == NO_EVENT ? STANDARD_MESSAGE : SYSTEM_MESSAGE;
        m.messageDate = [NSDate date];
        m.ownerContact = [HomeUser sharedHomeUser].homeUser;
        m.sessionId = self.session.sId;
        if (img)
            m.messageImage = img;
        //[[SessionManager sharedSessionManager] sendChatMessageToRemoteParty:m];
        [self.session addMessage:m];
        [m release];
        [self setMessage:m];
        messageTextbox.text = nil;
        
        if (recipient)
        {
            if ([self.session getConversationThread])
            {
                [self.session getConversationThread]->sendMessage([m.messageId UTF8String], [m.messageType UTF8String], [m.messageBody UTF8String]);
            }
            if (!(m.typeOfMessage == SYSTEM_MESSAGE && messageEvent == CALL_INCOMING))
            {
                [[HookflashSoundsManager sharedHookflashSoundsManager] playMessageSendSound];
            }
        }
        
        [self refreshViewWithData];
    }
}

-(void)sendIMmessage:(NSString *)message
{
    [[ActionManager sharedActionManager] sendMessage:message messageType:STANDARD_MESSAGE messageEvent:NO_EVENT forSession:self.session ];
    
    messageTextbox.text = nil;
    
    [[HookflashMasterManager sharedHookflashMasterManager] registerAchievementForKey: @"hookflash_master_achievement_text_message"];
    [[HookflashMasterManager sharedHookflashMasterManager] showCompletionIfNeededForNavigationController: self.navigationController];
}
-(void)addIMSystemMessage:(NSString *)message forMessageEvent:(MessageEvent)messageEvent
{
    if(message && [[message stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] > 0 )
    {
        Message *m = [[Message alloc] init];
        m.messageText = message;
        m.typeOfMessage = SYSTEM_MESSAGE;
        m.messageDate = [NSDate date];
        m.ownerContact = [HomeUser sharedHomeUser].homeUser;
        m.sessionId = self.session.sId;
        m.messageEvent = messageEvent;
        //[[SessionManager sharedSessionManager] sendChatMessageToRemoteParty:m];
        [self.session addMessage:m];
        [m release];
        [self setMessage:m];
        messageTextbox.text = nil;
        
        [self refreshViewWithData];
    }    
}

//Implement in child class
-(void)callIsEnded:(NSNotification *)notification
{
    [[NSNotificationCenter defaultCenter] postNotificationName:kDismissPopOver object:nil];
}

-(IBAction)startVideoSession:(id)sender
{
    self.session.type = VIDEO_CALL;
    [[ActionManager sharedActionManager] makeCallForSession:self.session];
}

-(IBAction)startAudioSession:(id)sender
{
    self.session.type = AUDIO_CALL;
    [[ActionManager sharedActionManager] makeCallForSession:self.session];
}

-(void)setDefaults
{
    //implemented in child classes
}

- (void) setKeyboardIsHidden:(BOOL) hidden
{
    keyboardIsHidden = hidden;
}

#pragma mark TTTAttributedLabelDelegate
- (void)attributedLabel:(TTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)url
{
    IMURLViewerViewController *IMURLViewer = [[IMURLViewerViewController alloc] initWithUrl:url];
    IMURLViewer.delegate = self;
    //[[((HookflashAppDelegate*)[[UIApplication sharedApplication] delegate]).window rootViewController] presentModalViewController:IMURLViewer animated:YES ];
    
    [[((HookflashAppDelegate*)[[UIApplication sharedApplication] delegate]).window rootViewController]  presentViewController:IMURLViewer animated:YES completion:NULL];
    [IMURLViewer release];
}

- (void)closeIMURLViewer
{
    [[((HookflashAppDelegate*)[[UIApplication sharedApplication] delegate]).window rootViewController] dismissModalViewControllerAnimated:YES];
}
*/

- (void) actionCallMenu
{
    /*if(audioSessionViewController != nil)
    {
        NSLog(@"%d", [[audioSessionViewController.view subviews] count]);
        if([[audioSessionViewController.view subviews] count] == 7)
        {
            [UIView animateWithDuration:0.5
                             animations:^{
                                 ((UIView *)[[audioSessionViewController.view subviews] objectAtIndex:6]).center = CGPointMake(160, 700);
                             }
                             completion:^(BOOL finished){
                                 
                                 [[[audioSessionViewController.view subviews] objectAtIndex:6] removeFromSuperview];
                                 
                             }];
            [((AudioCallViewController_iPhone*)audioSessionViewController).mediaNavigationViewController.buttonShowCallMenu setHidden:YES];
            
        }
        
        [messageTextbox resignFirstResponder];
        if ([audioSessionViewController.view superview] != self.view)
            [self.view addSubview:audioSessionViewController.view];
        
        ((AudioCallViewController_iPhone*)audioSessionViewController).mediaNavigationViewController.imgRightSeparator.hidden = YES;
        ((AudioCallViewController_iPhone*)audioSessionViewController).mediaNavigationViewController.buttonShowCallMenu.hidden = YES;
        
    }
    else if(videoContainerViewController != nil)
    {
        ((VideoViewController_iPhone*)videoContainerViewController).mediaNavigationViewController.buttonEndVideoCall.hidden = NO;
        ((VideoViewController_iPhone*)videoContainerViewController).mediaNavigationViewController.buttonShowCallMenu.hidden = YES;
        ((VideoViewController_iPhone*)videoContainerViewController).mediaNavigationViewController.imgRightSeparator.hidden = YES;
        
        [messageTextbox resignFirstResponder];
        if ([videoContainerViewController.view superview] != self.view)
        {
            [self.view addSubview:videoContainerViewController.view];
            [UIView animateWithDuration:0.5
                             animations:^{
                                 videoContainerViewController.view.center = CGPointMake(160, 208);
                             }
                             completion:^(BOOL finished)
             {
             }];
        }
    }
    else*/
    {
        UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:NSLocalizedString(@"Call options", @"")
                                                            delegate:self
                                                   cancelButtonTitle:nil
                                              destructiveButtonTitle:nil
                                                   otherButtonTitles:nil];
        
        NSMutableArray* buttonTitles = [[NSMutableArray alloc] init];
        
        //int i = 0;
        
        [buttonTitles addObject:NSLocalizedString(@"Audio Call", @"")];
        [buttonTitles addObject:NSLocalizedString(@"Video Call", @"")];
        [buttonTitles addObject:NSLocalizedString(@"Close session", @"")];
        [buttonTitles addObject:NSLocalizedString(@"Cancel", @"")];
        
        if (action)
        {
            for (int i = 0; i < [buttonTitles count]; i++)
            {
                [action addButtonWithTitle:[buttonTitles objectAtIndex:i]];
            }
            //
            //        action.tag = ACTION_TAG_FILTER;
            //CGRect frame = self.view.superview.frame;
            [action showFromRect:self.view.frame inView:self.view.superview animated:YES];
        }
    }
    
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex;
{
    NSLog(@"index: %d", buttonIndex);
    
    /*switch (buttonIndex)
    {
        case 0:
            [self startAudioSession:nil];
            break;
        case 1:
            [self startVideoSession:nil];
            break;
        case 2:
            [self closeSession:nil];
            break;
        default:
            break;
    }*/
}
@end
