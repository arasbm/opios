//
//  InfoViewController.h
//  OpenPeerSampleApp
//
//  Created by Sergej on 9/4/13.
//  Copyright (c) 2013 Hookflash. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface InfoViewController : UITableViewController<NSFetchedResultsControllerDelegate>

@end
