//
//  SettingsViewController.h
//  OpenPeerSampleApp
//
//  Created by Sergej on 9/2/13.
//  Copyright (c) 2013 Hookflash. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface SettingsViewController : UITableViewController




@end
